
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import * 
from PyQt5.QtGui import * 
from PyQt5.QtCore import Qt
import sys
from PyQt5 import uic  
import signal
import os
import subprocess
import time

from main_ui import Ui_MainWindow

os.chdir('web')
time.sleep(1)
subprocess.Popen(["flask","run"])
os.chdir('../')
time.sleep(2)

class MainWindow(QMainWindow):
    def __init__(self):
        QMainWindow.__init__(self)
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        self.setWindowTitle("Rage Weather App")

        self.setWindowFlag(Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.show()



        self.button = self.findChild(QtWidgets.QPushButton, 'close')
        self.button.clicked.connect(self.exit) 
        
        self.button1 = self.findChild(QtWidgets.QPushButton, 'mini')
        self.button1.clicked.connect(self.showMinimized)    


    def exit(self):
        try:
            os.system("taskkill /IM flask.exe /F")
            print("BYE !!")         
        except:
            print("Its's A BUG")

        sys.exit()



    def mousePressEvent(self, event):
        if event.button() == QtCore.Qt.LeftButton:
            self.offset = event.pos()
        else:
            super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self.offset is not None and event.buttons() == QtCore.Qt.LeftButton:
            self.move(self.pos() + event.pos() - self.offset)
        else:
            super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        self.offset = None
        super().mouseReleaseEvent(event)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    sys.exit(app.exec_())
import subprocess
import os
os.system('python main.py')